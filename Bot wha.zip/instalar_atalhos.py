import os
import sys

def main():
    # Detecta se está no termux (Linux/Android)
    if os.name != 'posix':
        print("⚠️ Este script de atalhos foi feito para o Termux (Celular).")
        print("Para Windows, os atalhos precisariam ser configurados via PowerShell.")
        return

    bashrc_path = os.path.expanduser("~/.bashrc")
    bot_dir = os.path.abspath(os.path.dirname(__file__))

    # Verifica se os aliases já existem
    if os.path.exists(bashrc_path):
        with open(bashrc_path, 'r') as f:
            content = f.read()
            if "alias bot:=" in content:
                print("✅ Os atalhos já estão instalados!")
                return

    aliases = f"""
# Atalhos do Bot de Vendas
alias bot:="cd '{bot_dir}' && python bot.py"
alias painel:="cd '{bot_dir}' && python admin.py"
"""

    try:
        with open(bashrc_path, 'a') as f:
            f.write(aliases)
        
        print("✅ Atalhos globais instalados com sucesso no Termux!")
        print("➡️ Para ativar os atalhos agora, digite o seguinte comando e dê Enter:")
        print("source ~/.bashrc")
        print("\nDepois disso, você poderá digitar apenas 'bot:' ou 'painel:' em qualquer tela!")
    except Exception as e:
        print(f"❌ Erro ao instalar atalhos: {e}")

if __name__ == "__main__":
    main()
