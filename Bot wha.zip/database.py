import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "loja.db")

def get_connection():
    return sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10.0)

def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    
    # Tabela de produtos
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            content TEXT NOT NULL
        )
    """)
    
    # Tabela de transacoes
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id TEXT PRIMARY KEY,
            user_phone TEXT NOT NULL,
            product_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            status TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            gateway TEXT DEFAULT 'misticpay',
            stanza_id TEXT,
            participant TEXT,
            FOREIGN KEY(product_id) REFERENCES products(id)
        )
    """)
    
    # Adicionar colunas se não existirem (evita erro de migration complexa)
    try:
        cursor.execute("ALTER TABLE transactions ADD COLUMN gateway TEXT DEFAULT 'misticpay'")
    except sqlite3.OperationalError:
        pass
    try:
        cursor.execute("ALTER TABLE transactions ADD COLUMN stanza_id TEXT")
    except sqlite3.OperationalError:
        pass
    try:
        cursor.execute("ALTER TABLE transactions ADD COLUMN participant TEXT")
    except sqlite3.OperationalError:
        pass
    try:
        cursor.execute("ALTER TABLE transactions ADD COLUMN coupon_code TEXT")
    except sqlite3.OperationalError:
        pass
        
    # Tabela de cupons
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS coupons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            discount_type TEXT NOT NULL, -- 'percent' ou 'fixed'
            discount_value REAL NOT NULL,
            uses INTEGER DEFAULT 0,
            max_uses INTEGER DEFAULT 100,
            active INTEGER DEFAULT 1
        )
    """)
        
    # Tabela de configuracoes gerais
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)
    
    # Gateway e Configurações padrões iniciais
    cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('active_gateway', 'misticpay')")
    cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('expiration_time', '15')")
    
    # Inserir produto de exemplo se tabela estiver vazia
    cursor.execute("SELECT COUNT(*) FROM products")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO products (name, price, content) VALUES (?, ?, ?)",
                       ("E-book: Python para Bots", 1.00, "Link de download do E-book: https://exemplo.com/ebook-download"))
    
    conn.commit()
    conn.close()

# --- COUPONS CRUD ---
def get_coupons():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, code, discount_type, discount_value, uses, max_uses, active FROM coupons")
    rows = cursor.fetchall()
    conn.close()
    return [{"id": r[0], "code": r[1], "type": r[2], "value": r[3], "uses": r[4], "max_uses": r[5], "active": bool(r[6])} for r in rows]

def get_coupon_by_code(code):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, code, discount_type, discount_value, uses, max_uses, active FROM coupons WHERE code = ?", (code.upper(),))
    row = cursor.fetchone()
    conn.close()
    if row:
        return {"id": row[0], "code": row[1], "type": row[2], "value": row[3], "uses": row[4], "max_uses": row[5], "active": bool(row[6])}
    return None

def apply_coupon_discount(code, original_price):
    coupon = get_coupon_by_code(code)
    if not coupon:
        return False, "Cupom não encontrado.", original_price
    if not coupon["active"]:
        return False, "Este cupom foi desativado.", original_price
    if coupon["uses"] >= coupon["max_uses"]:
        return False, "Este cupom atingiu o limite de usos.", original_price
        
    new_price = original_price
    if coupon["type"] == "percent":
        new_price -= original_price * (coupon["value"] / 100.0)
    elif coupon["type"] == "fixed":
        new_price -= coupon["value"]
        
    new_price = max(0.0, new_price) # Permite R$0.0 para gratuidade 100%
    return True, "Cupom aplicado com sucesso!", new_price

def increment_coupon_use(code):
    if not code:
        return
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE coupons SET uses = uses + 1 WHERE code = ?", (code.upper(),))
    conn.commit()
    conn.close()

def decrement_coupon_use(code):
    if not code:
        return
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE coupons SET uses = MAX(0, uses - 1) WHERE code = ?", (code.upper(),))
    conn.commit()
    conn.close()

def add_coupon(code, discount_type, discount_value, max_uses):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO coupons (code, discount_type, discount_value, max_uses) VALUES (?, ?, ?, ?)", 
                      (code.upper(), discount_type, discount_value, max_uses))
        conn.commit()
        success = True
    except sqlite3.IntegrityError:
        success = False
    conn.close()
    return success

def delete_coupon(coupon_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM coupons WHERE id = ?", (coupon_id,))
    conn.commit()
    conn.close()

# --- SETTINGS ---
def get_setting(key):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else None

def set_setting(key, value):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
    conn.commit()
    conn.close()

# --- PRODUCTS CRUD ---
def get_products():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, price, content FROM products")
    products = cursor.fetchall()
    conn.close()
    return [{"id": p[0], "name": p[1], "price": p[2], "content": p[3]} for p in products]

def get_product(product_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, price, content FROM products WHERE id = ?", (product_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return {"id": row[0], "name": row[1], "price": row[2], "content": row[3]}
    return None

def add_product(name, price, content):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO products (name, price, content) VALUES (?, ?, ?)", (name, price, content))
    conn.commit()
    conn.close()

def update_product(product_id, name, price, content):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE products SET name = ?, price = ?, content = ? WHERE id = ?", (name, price, content, product_id))
    conn.commit()
    conn.close()

def delete_product(product_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM products WHERE id = ?", (product_id,))
    conn.commit()
    conn.close()

# --- TRANSACTIONS ---
def create_transaction(tx_id, user_phone, product_id, amount, gateway="misticpay", stanza_id=None, participant=None, coupon_code=None):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO transactions (id, user_phone, product_id, amount, status, gateway, stanza_id, participant, coupon_code)
        VALUES (?, ?, ?, ?, 'PENDENTE', ?, ?, ?, ?)
    """, (tx_id, user_phone, product_id, amount, gateway, stanza_id, participant, coupon_code))
    conn.commit()
    conn.close()

def update_transaction_status(tx_id, status):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE transactions SET status = ? WHERE id = ?", (status, tx_id))
    conn.commit()
    conn.close()

def get_pending_transactions():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, user_phone, product_id, amount, gateway, stanza_id, participant, coupon_code FROM transactions WHERE status = 'PENDENTE'")
    rows = cursor.fetchall()
    conn.close()
    
    pending = []
    for r in rows:
        tx = {
            "id": r[0],
            "user_phone": r[1],
            "product_id": r[2],
            "amount": r[3],
            "gateway": r[4] if len(r)>4 else 'misticpay',
            "stanza_id": r[5] if len(r)>5 else None,
            "participant": r[6] if len(r)>6 else None,
            "coupon_code": r[7] if len(r)>7 else None
        }
        pending.append(tx)
    return pending

def get_user_purchases(user_phone):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT p.name, p.content, t.created_at
        FROM transactions t
        JOIN products p ON t.product_id = p.id
        WHERE t.user_phone = ? AND (t.status = 'APROVADO' OR t.status = 'PAID' OR t.status = 'PAGO')
        ORDER BY t.created_at DESC
    """, (user_phone,))
    rows = cursor.fetchall()
    conn.close()
    return [{"name": r[0], "content": r[1], "date": r[2]} for r in rows]

def get_all_transactions():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT t.id, t.user_phone, p.name, t.amount, t.status, t.created_at, t.gateway
        FROM transactions t
        LEFT JOIN products p ON t.product_id = p.id
        ORDER BY t.created_at DESC LIMIT 50
    """)
    rows = cursor.fetchall()
    conn.close()
    return [{"id": r[0], "user_phone": r[1], "product": r[2], "amount": r[3], "status": r[4], "date": r[5], "gateway": r[6] if len(r)>6 else 'misticpay'} for r in rows]

if __name__ == "__main__":
    init_db()
    print("Database initialized.")
