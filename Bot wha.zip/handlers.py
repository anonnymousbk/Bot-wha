import time
import database
import misticpay
import mercadopago_api

def handle_message(client, ev):
    # Pega os objetos usando a sintaxe correta da API
    msg_obj = getattr(ev, 'Message', None)
    info_obj = getattr(ev, 'Info', None)
    
    if not msg_obj:
        return
        
    text = ""
    try:
        if msg_obj.conversation:
            text = msg_obj.conversation
        elif msg_obj.extendedTextMessage and msg_obj.extendedTextMessage.text:
            text = msg_obj.extendedTextMessage.text
    except Exception:
        pass
        
    if not text:
        return
        
    text = text.strip().lower()
    
    try:
        user = str(info_obj.MessageSource.Chat.User)
        server = str(info_obj.MessageSource.Chat.Server)
        if not server:
            server = "s.whatsapp.net"
        sender_id = f"{user}@{server}"
    except Exception:
        sender_id = "unknown"

    try:
        # HUMANIZAÇÃO: Espera 2 segundos antes de responder (Simula leitura e digitação)
        time.sleep(2)
        
        # MENU PRINCIPAL
        menu_keywords = ['oi', 'ola', 'olá', 'menu', 'voltar', 'inicio', 'início']
        if text in menu_keywords:
            msg = (
                "👋 Olá! Bem-vindo(a) ao atendimento corporativo da *DougoBrasil*.\n\n"
                "Por favor, escolha uma das opções abaixo digitando o número correspondente:\n"
                "1️⃣ - Ver Catálogo de Produtos\n"
                "2️⃣ - Como funciona a entrega?\n"
                "3️⃣ - Falar com um Atendente\n"
                "4️⃣ - Minhas Compras\n\n"
                "💎 _DougoBrasil - Qualidade e Confiança_"
            )
            client.reply_message(msg, ev)
            return
            
        # OPÇÃO 1: CATÁLOGO
        if text == "1":
            products = database.get_products()
            if not products:
                client.reply_message("😔 Nenhum produto cadastrado no momento.", ev)
                return
                
            msg = "📚 *Catálogo de Produtos - DougoBrasil*\n\n"
            for p in products:
                msg += f"🔸 *ID:* {p['id']} | *{p['name']}*\n   💳 Valor: R$ {p['price']:.2f}\n\n"
                
            msg += "🛒 *Para comprar:* digite *comprar [ID]* (ex: comprar 1).\n"
            msg += "🎫 *Se tiver cupom:* digite *comprar [ID] [CUPOM]* (ex: comprar 1 DOUGO10)."
            client.reply_message(msg, ev)
            return
            
        # OPÇÃO 2: COMO FUNCIONA
        if text == '2':
            msg = (
                "❓ *Como funciona a entrega?*\n\n"
                "1️⃣ Você escolhe o produto e digita o comando de compra.\n"
                "2️⃣ O bot gera um PIX (Copia e Cola) exclusivo para você.\n"
                "3️⃣ Você realiza o pagamento no seu banco.\n"
                "4️⃣ Em até 15 segundos o sistema identifica o pagamento e te envia o produto automaticamente por aqui mesmo!\n\n"
                "🔙 Voltar ao menu: digite *menu*"
            )
            client.reply_message(msg, ev)
            return
            
        # OPÇÃO 3: ATENDENTE
        if text == '3':
            msg = (
                "👨‍💻 *Atendimento Humanizado - DougoBrasil*\n\n"
                "Nossa equipe de suporte está pronta para te ajudar!\n"
                "🕒 Horário de atendimento: Seg a Sex, das 09h às 18h.\n\n"
                "Por favor, detalhe sua dúvida aqui mesmo ou acesse nosso link direto de suporte: https://wa.me/5511999999999\n\n"
                "⏳ _Um de nossos especialistas responderá o mais breve possível._"
            )
            client.reply_message(msg, ev)
            return

        # OPÇÃO 4: MINHAS COMPRAS
        if text == '4' or text == 'compras':
            purchases = database.get_user_purchases(sender_id)
            if not purchases:
                client.reply_message("Você ainda não tem compras aprovadas conosco.", ev)
            else:
                msg = "💼 *Suas Compras - DougoBrasil:*\n\n"
                for purchase in purchases:
                    msg += f"📦 *{purchase['name']}*\n🔗 {purchase['content']}\n\n"
                msg += "🔙 Voltar ao menu: digite *menu*"
                client.reply_message(msg, ev)
            return

        # FLUXO DE COMPRA
        if text.startswith("comprar"):
            parts = text.split()
            if len(parts) < 2:
                client.reply_message("Formato inválido. Digite *comprar [ID]* ou *comprar [ID] [CUPOM]*", ev)
                return
                
            product_id = parts[1]
            coupon_code = parts[2] if len(parts) > 2 else None
            
            # Prevenção de Spam (Bloqueia múltiplos pedidos simultâneos)
            pendentes = database.get_pending_transactions()
            if any(tx['user_phone'] == sender_id for tx in pendentes):
                expiration_minutes = database.get_setting('expiration_time') or 15
                client.reply_message(f"⏳ *Você já tem um pedido aguardando pagamento!*\nPor favor, pague o PIX gerado ou aguarde o cancelamento automático ({expiration_minutes} minutos) antes de abrir um novo pedido.", ev)
                return
                
            prod = database.get_product(product_id)
            if not prod:
                client.reply_message("❌ Produto não encontrado. Verifique o ID no catálogo.", ev)
                return
                
            price = prod['price']
            if coupon_code:
                success, c_msg, new_price = database.apply_coupon_discount(coupon_code, price)
                if not success:
                    client.reply_message(f"❌ *Cupom Inválido:*\n{c_msg}", ev)
                    return
                price = new_price
                
            # Verifica se o produto saiu de graça (Cupom de 100%)
            if price <= 0:
                msg = f"🎉 *Presente Liberado!* 🎉\n\nSeu cupom de 100% de desconto foi aplicado com sucesso.\n\nAqui está o seu produto:\n{prod['content']}\n\n_Equipe DougoBrasil_"
                client.reply_message(msg, ev)
                if coupon_code:
                    database.increment_coupon_use(coupon_code)
                return
                
            client.reply_message(f"⏳ Gerando cobrança PIX para *{prod['name']}* no valor de R$ {price:.2f}, aguarde...", ev)
            
            # Reserva do uso do cupom instantânea
            if coupon_code:
                database.increment_coupon_use(coupon_code)
                
            # Determinar qual gateway usar
            gateway = database.get_setting('active_gateway') or 'misticpay'
            
            # Cria a cobrança na API correta
            if gateway == "mercadopago":
                from mercadopago_api import create_pix_charge
                success, tx_id, pix_data = create_pix_charge(price, f"Produto: {prod['name']}")
            else:
                from misticpay import create_pix_charge
                success, tx_id, pix_data = create_pix_charge(price, f"Produto: {prod['name']}")
            
            if success:
                import urllib.parse
                
                stanza_id = info_obj.ID
                sender_user = str(info_obj.MessageSource.Sender.User)
                sender_server = str(info_obj.MessageSource.Sender.Server)
                participant = f"{sender_user}@{sender_server}"
                
                database.create_transaction(tx_id, sender_id, product_id, price, gateway, stanza_id, participant, coupon_code)
                
                pix_code = pix_data.get('copyPaste') or pix_data.get('pixCopiaECola') or pix_data.get('payload') or "Código PIX não retornado."
                qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={urllib.parse.quote(pix_code)}"
                # Mensagem enxuta e profissional (agora será a legenda da imagem)
                msg = (
                    f"✅ *Pedido Gerado com Sucesso*\n\n"
                    f"📦 *Produto:* {prod['name']}\n"
                    f"💰 *Valor:* R$ {price:.2f}\n\n"
                    f"⏳ _Aguardando confirmação do pagamento..._"
                )
                
                try:
                    # Baixa a imagem manualmente para evitar erros da biblioteca
                    import requests
                    img_bytes = requests.get(qr_url, timeout=10).content
                    
                    # Envia o QR Code como IMAGEM nativa no WhatsApp
                    client.send_image(
                        to=info_obj.MessageSource.Chat,
                        file=img_bytes,
                        caption=msg
                    )
                except Exception as e:
                    print(f"Erro ao enviar imagem: {e}")
                    # Fallback para mensagem de texto caso a imagem falhe
                    client.reply_message(msg + f"\n\nPara pagar, acesse o QR Code pelo link:\n🔗 {qr_url}", ev)
                
                # Envia o PIX separadamente para facilitar a cópia
                time.sleep(1)
                client.reply_message("📲 *PIX Copia e Cola:* 👇", ev)
                client.reply_message(pix_code, ev)
            else:
                client.reply_message(f"❌ *Erro ao gerar PIX:*\n{tx_id}", ev)
            return

    except Exception as e:
        print(f"[ERRO HANDLER] Falha ao processar mensagem de {sender_id}: {e}")
        try:
            client.reply_message("⚠️ *Ocorreu um erro interno ao processar seu pedido.* Tente novamente mais tarde.", ev)
        except:
            pass
