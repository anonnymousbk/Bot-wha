import os
import uuid
import requests
from dotenv import load_dotenv

load_dotenv()

CLIENT_ID = os.getenv("MISTICPAY_CLIENT_ID")
CLIENT_SECRET = os.getenv("MISTICPAY_CLIENT_SECRET")
BASE_URL = os.getenv("MISTICPAY_BASE_URL", "https://api.misticpay.com/api").rstrip('/')

def get_headers():
    return {
        "ci": CLIENT_ID.strip() if CLIENT_ID else "",
        "cs": CLIENT_SECRET.strip() if CLIENT_SECRET else "",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

def create_pix_charge(amount: float, description: str = "Compra WhatsApp"):
    """
    Cria uma cobrança PIX usando o endpoint /transactions/create
    """
    url = f"{BASE_URL}/transactions/create"
    tx_id = f"tx_{uuid.uuid4().hex[:10]}"
    
    payload = {
        "amount": amount,
        "payerName": "Cliente WhatsApp",
        "payerDocument": "00000000000",
        "transactionId": tx_id,
        "description": description
    }
    
    try:
        response = requests.post(url, json=payload, headers=get_headers(), timeout=10)
        data = response.json()
        
        if response.status_code in [200, 201] and "data" in data:
            tx_data = data["data"]
            return True, tx_data.get("transactionId", tx_id), tx_data
        else:
            msg = data.get("message") or data.get("error") or str(data)
            return False, f"Erro {response.status_code}: {msg}", None
    except Exception as e:
        return False, str(e), None

def check_payment_status(transaction_id: str):
    """
    Verifica o status usando o endpoint /transactions/check
    """
    url = f"{BASE_URL}/transactions/check"
    payload = {
        "transactionId": str(transaction_id)
    }
    try:
        response = requests.post(url, json=payload, headers=get_headers(), timeout=10)
        if response.status_code == 200:
            data = response.json()
            tx_obj = data.get("transaction") or data.get("data", {})
            if isinstance(tx_obj, list) and len(tx_obj) > 0:
                tx_obj = tx_obj[0]
            
            if isinstance(tx_obj, dict):
                state = tx_obj.get("transactionState") or tx_obj.get("state") or tx_obj.get("status") or "PENDENTE"
                return str(state).upper()
        return None
    except Exception:
        return None
