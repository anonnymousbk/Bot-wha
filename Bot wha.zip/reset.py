import sqlite3
conn = sqlite3.connect('loja.db')
conn.execute("UPDATE transactions SET status='PENDENTE' WHERE status='PAID'")
conn.commit()
conn.close()
print("Transacoes revertidas!")
