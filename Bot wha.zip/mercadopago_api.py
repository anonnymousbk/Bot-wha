import os
import uuid
import mercadopago
from dotenv import load_dotenv

load_dotenv()

MP_ACCESS_TOKEN = os.getenv("MP_ACCESS_TOKEN", "APP_USR-2908397834906719-030608-68524f456ffb7b7c140ee534600d8517-3247437535")

def get_sdk():
    return mercadopago.SDK(MP_ACCESS_TOKEN)

def create_pix_charge(amount: float, description: str = "Compra WhatsApp"):
    """
    Cria uma cobrança PIX via Mercado Pago.
    Retorna (sucesso, transaction_id_ou_erro, payload_completo)
    """
    sdk = get_sdk()
    
    # Adicionando um número aleatório (uuid) para garantir que a requisição seja única (Idempotency Key)
    request_options = mercadopago.config.RequestOptions()
    request_options.custom_headers = {
        'x-idempotency-key': str(uuid.uuid4())
    }

    payment_data = {
        "transaction_amount": float(amount),
        "description": description,
        "payment_method_id": "pix",
        "payer": {
            "email": "cliente@whatsapp.bot",
            "first_name": "Cliente",
            "last_name": "WhatsApp"
        }
    }
    
    try:
        payment_response = sdk.payment().create(payment_data, request_options)
        payment = payment_response.get("response", {})
        
        if payment_response.get("status") in [200, 201] and payment.get("id"):
            tx_id = str(payment["id"])
            
            # O Mercado Pago retorna o QR Code em 'point_of_interaction'
            poi = payment.get("point_of_interaction", {})
            tx_data = poi.get("transaction_data", {})
            
            copy_paste = tx_data.get("qr_code", "QR Code não encontrado")
            
            # Estruturamos o payload igual ao misticpay para compatibilidade
            formatted_data = {
                "copyPaste": copy_paste,
                "qr_code_base64": tx_data.get("qr_code_base64")
            }
            
            return True, tx_id, formatted_data
        else:
            error_msg = payment.get("message", "Erro desconhecido")
            return False, f"Erro Mercado Pago: {error_msg}", None
            
    except Exception as e:
        return False, str(e), None

def check_payment_status(transaction_id: str):
    """
    Consulta o status de um pagamento pelo ID no Mercado Pago.
    Retorna o status em UPPERCASE.
    """
    sdk = get_sdk()
    try:
        payment_info = sdk.payment().get(transaction_id)
        if payment_info.get("status") == 200:
            status = payment_info.get("response", {}).get("status", "PENDING")
            return str(status).upper()
        return None
    except Exception:
        return None
