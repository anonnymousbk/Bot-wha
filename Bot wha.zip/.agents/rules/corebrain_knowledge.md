# CoreBrain Knowledge Saving Rule

Whenever you learn a new piece of knowledge, discover an important fact, or solve a complex problem during this project, you MUST record it in the directory `D:\CoreBrain_Knowledge`. 

Guidelines:
1. Create a markdown file with a descriptive name (e.g., `D:\CoreBrain_Knowledge\concept_name.md`).
2. Include the context, what was learned, and any code snippets or commands that are relevant.
3. Keep the information organized and easy to read.
4. Do this proactively without needing the user to explicitly ask for it each time.
