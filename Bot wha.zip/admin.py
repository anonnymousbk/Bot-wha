import os
import sys
import database

# Cores ANSI simples
RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RED = "\033[91m"

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def header(title):
    clear_screen()
    print(f"{CYAN}{BOLD}{'='*40}")
    print(f" {title.center(38)}")
    print(f"{'='*40}{RESET}\n")

def pause():
    input(f"\n{YELLOW}Pressione ENTER para continuar...{RESET}")

def manage_products():
    while True:
        header("GERENCIAR PRODUTOS")
        products = database.get_products()
        if not products:
            print(f"{RED}Nenhum produto cadastrado.{RESET}")
        else:
            for p in products:
                print(f"[{p['id']}] {BOLD}{p['name']}{RESET} - R$ {p['price']:.2f}")
                print(f"    Link: {p['content'][:50]}...")
                
        print("\n1. Adicionar Produto")
        print("2. Editar Produto")
        print("3. Remover Produto")
        print("4. Voltar")
        
        op = input("\nEscolha: ").strip()
        if op == '1':
            print("\n-- Adicionar Novo Produto --")
            name = input("Nome do Produto: ").strip()
            price_str = input("Preço (ex: 10.50): ").strip()
            content = input("Conteúdo/Link de Entrega: ").strip()
            try:
                database.add_product(name, float(price_str.replace(',', '.')), content)
                print(f"{GREEN}Produto adicionado!{RESET}")
            except Exception as e:
                print(f"{RED}Erro: {e}{RESET}")
            pause()
        elif op == '2':
            pid = input("\nID do produto para editar: ").strip()
            if pid.isdigit():
                prod = database.get_product(int(pid))
                if prod:
                    print(f"Editando: {prod['name']}")
                    name = input(f"Novo Nome [{prod['name']}]: ").strip() or prod['name']
                    price_str = input(f"Novo Preço [{prod['price']}]: ").strip() or str(prod['price'])
                    content = input(f"Novo Conteúdo [{prod['content'][:20]}...]: ").strip() or prod['content']
                    database.update_product(int(pid), name, float(price_str.replace(',', '.')), content)
                    print(f"{GREEN}Produto atualizado!{RESET}")
                else:
                    print(f"{RED}Produto não encontrado.{RESET}")
            pause()
        elif op == '3':
            pid = input("\nID do produto para remover: ").strip()
            if pid.isdigit():
                database.delete_product(int(pid))
                print(f"{GREEN}Produto removido!{RESET}")
            pause()
        elif op == '4':
            break

def manage_gateway():
    while True:
        header("CONFIGURAÇÃO DE GATEWAY")
        current = database.get_setting("active_gateway") or "misticpay"
        print(f"Gateway Ativo Atual: {GREEN}{BOLD}{current.upper()}{RESET}\n")
        
        print("1. Usar Mercado Pago")
        print("2. Usar MisticPay")
        print("3. Voltar")
        
        op = input("\nEscolha: ").strip()
        if op == '1':
            database.set_setting("active_gateway", "mercadopago")
            print(f"{GREEN}Gateway alterado para Mercado Pago!{RESET}")
            pause()
        elif op == '2':
            database.set_setting("active_gateway", "misticpay")
            print(f"{GREEN}Gateway alterado para MisticPay!{RESET}")
            pause()
        elif op == '3':
            break

def view_sales():
    from datetime import datetime, timezone, timedelta
    brt = timezone(timedelta(hours=-3))
    header("ÚLTIMAS VENDAS")
    txs = database.get_all_transactions()
    if not txs:
        print(f"{YELLOW}Nenhuma transação registrada ainda.{RESET}")
    else:
        for t in txs:
            color = GREEN if t['status'] in ['APROVADO', 'PAID', 'COMPLETO'] else RED if t['status'] in ['FALHA', 'FAILED'] else YELLOW
            prod_name = t['product'] or f"ID {t['product_id']}"
            try:
                utc_dt = datetime.strptime(t['date'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)
                local_dt = utc_dt.astimezone(brt)
                date_str = local_dt.strftime('%d/%m/%Y %H:%M:%S')
            except:
                date_str = t['date']
            print(f"{color}[{t['status']}]{RESET} - R$ {t['amount']:.2f} | Produto: {prod_name}")
            print(f"Cliente: {t['user_phone']} | Data: {date_str} | Gateway: {t['gateway']}")
            print("-" * 50)
    pause()

def manage_coupons():
    while True:
        header("GERENCIAR CUPONS")
        coupons = database.get_coupons()
        if not coupons:
            print(f"{YELLOW}Nenhum cupom cadastrado.{RESET}")
        else:
            for c in coupons:
                val = f"{c['value']}%" if c['type'] == 'percent' else f"R${c['value']:.2f}"
                status_color = GREEN if c['active'] else RED
                status_text = "ATIVO" if c['active'] else "INATIVO"
                print(f"[{c['id']}] {BOLD}{c['code']}{RESET} - {val} - Usos: {c['uses']}/{c['max_uses']} - {status_color}{status_text}{RESET}")
                
        print("\n1. Adicionar novo cupom")
        print("2. Remover cupom")
        print("3. Voltar")
        
        op = input("\nEscolha: ").strip()
        if op == '1':
            code = input("Código do cupom (ex: DOUGO10): ").strip().upper()
            type_str = input("Tipo (percent ou fixed): ").strip().lower()
            val_str = input("Valor (ex: 10 para 10% ou 5 para R$5): ").strip()
            max_uses_str = input("Limite de usos: ").strip()
            try:
                if database.add_coupon(code, type_str, float(val_str.replace(',', '.')), int(max_uses_str)):
                    print(f"{GREEN}Cupom adicionado!{RESET}")
                else:
                    print(f"{RED}Erro ao adicionar cupom (código já existe).{RESET}")
            except Exception as e:
                print(f"{RED}Erro: {e}{RESET}")
            pause()
        elif op == '2':
            cid = input("ID do cupom para remover: ").strip()
            if cid.isdigit():
                database.delete_coupon(int(cid))
                print(f"{GREEN}Cupom removido!{RESET}")
            pause()
        elif op == '3':
            break

def main():
    # Garante que o DB está inicializado
    database.init_db()
    
    while True:
        header("PAINEL ADMIN DO BOT")
        print("1. 📦 Gerenciar Produtos")
        print("2. 💳 Configurar Gateway de Pagamento")
        print("3. 💰 Ver Vendas e Transações")
        print("4. 🎫 Gerenciar Cupons")
        print("5. ❌ Sair")
        
        op = input("\nEscolha uma opção: ").strip()
        if op == '1':
            manage_products()
        elif op == '2':
            manage_gateway()
        elif op == '3':
            view_sales()
        elif op == '4':
            manage_coupons()
        elif op == '5':
            print(f"\n{GREEN}Saindo do painel...{RESET}")
            sys.exit(0)

if __name__ == "__main__":
    main()
