import time
import os
import threading
import sqlite3
from datetime import datetime
import concurrent.futures
from mercadopago_api import check_payment_status

DB_PATH = os.path.join(os.path.dirname(__file__), "loja.db")

def get_connection():
    return sqlite3.connect(DB_PATH, check_same_thread=False)

def process_transaction(tx, client):
    import database
    from neonize.utils import build_jid
    
    tx_id = tx["id"]
    gateway = tx["gateway"]
    created_at_str = tx.get("created_at")
    
    # Verifica Expiração (15 minutos)
    if created_at_str:
        try:
            created_at = datetime.strptime(created_at_str, '%Y-%m-%d %H:%M:%S')
            if (datetime.utcnow() - created_at).total_seconds() > 15 * 60:
                print(f"[Daemon] Pedido {tx_id} expirou (15m). Cancelando...")
                database.update_transaction_status(tx_id, "CANCELADO")
                if tx.get("coupon_code"):
                    database.decrement_coupon_use(tx["coupon_code"])
                
                # Mensagem de Recuperação (Carrinho Abandonado)
                phone = tx["user_phone"]
                if "@" in phone:
                    user, server = phone.split("@", 1)
                    jid = build_jid(user, server)
                else:
                    jid = build_jid(phone)
                
                recovery_msg = (
                    "⚠️ *Aviso Importante - DougoBrasil*\n\n"
                    "O tempo limite de 15 minutos para o seu pagamento PIX expirou e o pedido foi cancelado por segurança.\n\n"
                    "Ainda tem interesse? Não perca essa chance! 🚀\n"
                    "Basta voltar ao menu e refazer o seu pedido rapidamente. Estamos te esperando!"
                )
                try:
                    client.send_message(jid, recovery_msg)
                except:
                    pass
                return
        except Exception as e:
            print(f"Erro na verificação de data: {e}")

    # Verifica o pagamento
    paid = False
    if gateway == "mercadopago":
        status = check_payment_status(tx_id)
        if status in ["APPROVED", "COMPLETED", "PAGO", "APROVADO", "SUCESSO", "PAID"]:
            paid = True
    else:
        import misticpay
        status = misticpay.check_payment_status(tx_id)
        if status in ["COMPLETO", "PAGO", "PAID", "APPROVED", "SUCESSO", "APROVADO", "COMPLETED"]:
            paid = True

    if paid:
        database.update_transaction_status(tx_id, "APROVADO")
        product = database.get_product(tx["product_id"])
        
        msg = f"🎉 *Pagamento Confirmado!* 🎉\n\nObrigado por comprar conosco.\n\nAqui está o seu produto:\n{product['content']}\n\n_Equipe DougoBrasil_"
        
        try:
            from neonize.utils import build_jid
            
            phone = tx["user_phone"]
            if "@" in phone:
                user, server = phone.split("@", 1)
                jid = build_jid(user, server)
            else:
                jid = build_jid(phone)
                
            stanza_id = tx.get("stanza_id")
            participant = tx.get("participant")
            
            if stanza_id and participant:
                try:
                    from neonize.proto.waE2E.WAWebProtobufsE2E_pb2 import Message, ExtendedTextMessage, ContextInfo
                    msg_proto = Message(
                        extendedTextMessage=ExtendedTextMessage(
                            text=msg,
                            contextInfo=ContextInfo(
                                stanzaID=stanza_id,
                                participant=participant
                            )
                        )
                    )
                    client.send_message(jid, msg_proto)
                except ImportError:
                    client.send_message(jid, msg)
            else:
                client.send_message(jid, msg)
                
            print(f"[Daemon] Produto entregue com sucesso para {tx['user_phone']} via {gateway}!")
        except Exception as e:
            print(f"Erro ao enviar mensagem de confirmacao: {e}")

def run_daemon(client):
    import database
    print("[Daemon] Polling iniciado com Multithreading e Recuperação (15m)...")
    while True:
        try:
            pending = database.get_pending_transactions()
            if pending:
                with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                    for tx in pending:
                        # Buscamos a data completa pois precisamos para o expiry logic
                        conn = get_connection()
                        row = conn.cursor().execute("SELECT created_at FROM transactions WHERE id = ?", (tx["id"],)).fetchone()
                        conn.close()
                        if row:
                            tx["created_at"] = row[0]
                        executor.submit(process_transaction, tx, client)
        except Exception as e:
            print(f"[Daemon] Erro no loop principal: {e}")
            
        time.sleep(15)

def start_daemon(client):
    t = threading.Thread(target=run_daemon, args=(client,), daemon=True)
    t.start()
    return t
