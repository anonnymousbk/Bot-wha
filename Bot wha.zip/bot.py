# Patch para compatibilidade do neonize com Python 3.10
import typing
try:
    from typing import Self
except ImportError:
    from typing_extensions import Self
    typing.Self = Self

# Patch para evitar o erro de Access Violation no Windows (problema do ctypes no neonize)
try:
    # pyrefly: ignore [missing-import]
    import neonize.utils.log
    neonize.utils.log._worker = lambda *args, **kwargs: None
except:
    pass

from neonize.client import NewClient
from neonize.events import MessageEv, ConnectedEv, event
from handlers import handle_message
import payment_daemon
import database

# Inicia banco de dados
database.init_db()

# Inicializa o cliente do bot (Cria o banco de sessao local sqlite)
client = NewClient("loja_bot.sqlite")

@client.event(ConnectedEv)
def on_connected(client: NewClient, ev: ConnectedEv):
    print("⚡ Bot conectado com sucesso!")
    # Inicia a thread de polling para verificar pagamentos PIX
    payment_daemon.start_daemon(client)

@client.event(MessageEv)
def on_message(client: NewClient, ev: MessageEv):
    print("📥 [DEBUG] Evento de mensagem recebido!")
    try:
        is_from_me = ev.info.MessageSource.IsFromMe
        print(f"   De Mim: {is_from_me}")
    except:
        pass
    # Trata as mensagens recebidas
    handle_message(client, ev)

if __name__ == "__main__":
    print("Iniciando o bot...")
    print("⚠️  Se for a primeira vez, leia o QR Code com o WhatsApp ⚠️")
    client.connect()
    event.wait()
